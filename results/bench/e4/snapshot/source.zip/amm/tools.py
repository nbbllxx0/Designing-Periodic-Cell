"""Tool contract of the agent layer: typed tools, a logged session, and LLM-free replay.

Pattern from AgenticTO (agentto.tools), re-implemented for unit cells:
  * every tool is a Session method registered with @tool: arguments are validated by a pydantic model built from
    the signature (extra keys forbidden), the call runs, and one record is appended to session.jsonl
    {seq, t, actor, tool, args, ok, result | error, state_hash, dt_s};
  * `replay(log)` re-runs every call of a log in a fresh session without any LLM and compares ok, state hash and
    the full result (timing fields removed). The gate of week 4 is that replay is exact;
  * profiles select the tools an arm sees: "B" = spec, ask, evaluate, search, submit (no bounds, no certificates);
    "C" = everything ("full system"). Arm D has no tools.

Units: the agent states targets in physical units (Pa, Hz) or normalized ones ("E_s" = fraction of the solid's
Young's modulus, "f*" = f a / c_t). The session converts with amm.units; physics runs on normalized values.
Results carry both. Search-tier values are labelled as such and are never certificates.

Release rule in profile C: `submit(decision="release")` needs a certificate with verdict "certified" for that
design and the current targets, computed by `certify` in this session. The agent can read certificates but has no
way to write one.
"""
from __future__ import annotations

import copy
import datetime as _dt
import hashlib
import inspect
import json
import threading
import time
import typing
import uuid
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, create_model

from . import atlas, bounds, units

SCHEMA_VERSION = "amm-tools/1"
PROFILES = ("B", "C")
VOLATILE = ("seconds", "timing", "dt_s", "batch_seconds_per_cell", "static_s", "bloch_s", "t")
ATLAS_DIR = Path(__file__).resolve().parents[1] / "results" / "atlas"
MAX_EVAL = 16
# session budgets, equal for both arms (audit F07, 2026-11-06); never reached in the 56 development sessions
# (max 288 designs, 3 certificates)
MAX_SESSION_DESIGNS = 400
MAX_SESSION_CERTIFY = 4

# ----------------------------------------------------------------------------------------------------------------
# argument types
# ----------------------------------------------------------------------------------------------------------------
Family = Literal["tpms", "struts", "resonator"]
Kind = Literal["gyroid", "schwarz_p", "diamond", "iwp", "sc", "bcc", "octet", "cube_bars", "sphere_ligaments"]


class Stiffness(BaseModel):
    model_config = ConfigDict(extra="forbid")
    value: float
    unit: Literal["Pa", "kPa", "MPa", "GPa", "psi", "E_s"] = Field(
        description='"E_s": fraction of the solid material\'s Young\'s modulus')


class Gap(BaseModel):
    model_config = ConfigDict(extra="forbid")
    f_lo: float
    f_hi: float
    unit: Literal["Hz", "kHz", "MHz", "f*"] = Field(description='"f*": normalized frequency f a / c_t')


class Design(BaseModel):
    """A cell design. Parameters by kind: TPMS {density, mode: sheet|network}; sc/bcc/octet {r, R} (strut radius,
    node-sphere radius, R = 0 or R >= r + 0.03); cube_bars {c, w}; sphere_ligaments {c, w}. Lengths in cell units."""
    model_config = ConfigDict(extra="forbid")
    kind: Kind
    params: dict[str, float | str]


class ClarifyOption(BaseModel):
    model_config = ConfigDict(extra="forbid")
    label: str = Field(description="short answer text shown to the user")
    set: dict[str, Any] = Field(default_factory=dict, description=(
        'what choosing it sets, with the keys of the session state: material (name), cell_size ([value, unit]), '
        'gap_type ("complete"), or a target key (density_max, E100_min, G_min, bulk_min, nu100_min, nu100_max, '
        'gap)'))


# ----------------------------------------------------------------------------------------------------------------
# registry
# ----------------------------------------------------------------------------------------------------------------
TOOLS: dict[str, dict] = {}


def tool(*, mutates: bool = False, profiles=PROFILES, replay: str = "run"):
    def deco(fn):
        params = list(inspect.signature(fn).parameters.values())[1:]
        hints = typing.get_type_hints(fn, include_extras=True)
        fields = {p.name: (hints.get(p.name, Any), ... if p.default is inspect.Parameter.empty else p.default)
                  for p in params}
        model = create_model(f"{fn.__name__}_args", __config__=ConfigDict(extra="forbid"), **fields)
        TOOLS[fn.__name__] = dict(fn=fn, model=model, mutates=mutates, profiles=set(profiles), replay=replay,
                                  doc=inspect.getdoc(fn) or "", params=params)
        return fn
    return deco


class ToolError(ValueError):
    pass


def canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=_default)


def _default(o):
    try:
        import numpy as np
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:
        pass
    if isinstance(o, BaseModel):
        return o.model_dump(mode="json")
    raise TypeError(type(o).__name__)


def _plain(x):
    """JSON-plain copy (numpy scalars and arrays, pydantic models)."""
    return json.loads(canon(x))


def strip_volatile(x):
    if isinstance(x, dict):
        return {k: strip_volatile(v) for k, v in x.items() if k not in VOLATILE}
    if isinstance(x, list):
        return [strip_volatile(v) for v in x]
    return x


def result_hash(result) -> str:
    return hashlib.sha256(canon(strip_volatile(result)).encode()).hexdigest()[:16]


NOT_HASHED = ("bench.py", "llm.py", "mcp_server.py")


def code_hash() -> str:
    """Hash of the sources that determine tool results: a replay is exact only against the code that wrote the
    log. Excluded: the clarification oracle (bench.py; replay takes answers from the log), the CLI runner (llm.py)
    and the MCP transport (mcp_server.py)."""
    h = hashlib.sha256()
    for f in sorted(Path(__file__).resolve().parent.glob("*.py")):
        if f.name in NOT_HASHED:
            continue
        h.update(f.name.encode() + f.read_bytes())
    return h.hexdigest()[:16]


def _now():
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds")


def _short_errors(ex: ValidationError) -> str:
    return "; ".join(f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in ex.errors()[:6])


_ATLAS: dict[float, list] = {}


def atlas_rows(nu: float) -> list | None:
    """Atlas rows at this Poisson ratio, or None when no atlas exists for it."""
    key = round(nu, 4)
    if key not in _ATLAS:
        p = ATLAS_DIR / f"atlas_nu{nu:g}.jsonl"
        _ATLAS[key] = atlas.load(str(p)) if p.exists() else None
    return _ATLAS[key]


# ----------------------------------------------------------------------------------------------------------------
# session
# ----------------------------------------------------------------------------------------------------------------
class Session:
    def __init__(self, root: str | Path | None = None, profile: str = "C", answerer=None):
        if profile not in PROFILES:
            raise ValueError(f"profile must be one of {PROFILES}")
        self.root = Path(root) if root is not None else None
        self.profile = profile
        self.state: dict = dict(material=None, cell_size=None, targets={}, families=["tpms", "struts", "resonator"],
                                sources={}, gap_type=None)
        self.certs: dict[str, dict] = {}          # key(design, targets) -> certificate summary
        self.used = dict(designs=0, certify=0)    # session budget use (MAX_SESSION_*)
        self.submission: dict | None = None
        self.undo_stack: list = []
        self.seq = 0
        self.answerer = answerer                  # callable(question, options) -> {"choice", "label", "comment"}
        self.replay_answer: dict | None = None
        self._lock = threading.RLock()            # MCP clients may send calls concurrently: run them one at a time
        self.log_path = None
        if self.root is not None:
            self.root.mkdir(parents=True, exist_ok=True)
            self.log_path = self.root / "session.jsonl"
            self._append(dict(type="session", t=_now(), schema=SCHEMA_VERSION, id=uuid.uuid4().hex[:12],
                              profile=profile, code=code_hash()))

    # ---- plumbing --------------------------------------------------------------------------------------------
    def _append(self, rec: dict):
        if self.log_path is not None:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(canon(rec) + "\n")

    def state_hash(self) -> str:
        s = dict(self.state, certs=sorted(self.certs), submission=self.submission)
        return hashlib.sha256(canon(s).encode()).hexdigest()[:16]

    def tools(self) -> list[str]:
        return [n for n, t in TOOLS.items() if self.profile in t["profiles"]]

    def call(self, name: str, args: dict | None = None, actor: str = "script") -> dict:
        """Validate, run and log one call (serialized, so the log order is the execution order). Returns
        {"ok", "seq", "result" | "error", "state_hash"}."""
        with self._lock:
            return self._call(name, args, actor)

    def _call(self, name: str, args: dict | None, actor: str) -> dict:
        args = dict(args or {})
        if name not in TOOLS or self.profile not in TOOLS[name]["profiles"]:
            return dict(ok=False, error=f"unknown tool {name!r}")
        t = TOOLS[name]
        self.seq += 1
        seq = self.seq
        t0 = time.perf_counter()
        before = copy.deepcopy(self.state)
        answer = None
        try:
            parsed = t["model"].model_validate(args)
            kw = {p.name: getattr(parsed, p.name) for p in t["params"]}
            result = _plain(t["fn"](self, **kw))
            ok, err = True, None
            if name == "ask_clarification":
                answer = result.get("answer")
        except ValidationError as ex:
            ok, err, result = False, _short_errors(ex), None
        except (ToolError, ValueError) as ex:
            ok, err, result = False, str(ex), None
        except Exception as ex:                    # noqa: BLE001 -- a tool bug is reported, never kills the server
            ok, err, result = False, f"internal error: {type(ex).__name__}: {ex}", None
        if not ok and t["mutates"]:
            self.state = before
        elif ok and t["mutates"] and name != "undo" and before != self.state:
            self.undo_stack.append(before)
        rec = dict(type="call", seq=seq, t=_now(), actor=actor, tool=name, args=_plain(args), ok=ok,
                   state_hash=self.state_hash(), dt_s=round(time.perf_counter() - t0, 3))
        if ok:
            rec["result"] = result
            rec["result_hash"] = result_hash(result)
        else:
            rec["error"] = err
        if answer is not None:
            rec["answer"] = answer
        self._append(rec)
        out = dict(ok=ok, seq=seq, state_hash=rec["state_hash"])
        out.update(dict(result=result) if ok else dict(error=err))
        return out

    # ---- helpers ---------------------------------------------------------------------------------------------
    def _material(self) -> dict | None:
        m = self.state["material"]
        if m is None:
            return None
        return units.MATERIALS[m] if isinstance(m, str) else m

    def _nu(self) -> float:
        m = self._material()
        if m is None:
            raise ToolError("no material: call set_material first (the solid's Poisson ratio enters every solve)")
        return float(m["nu"])

    def request(self) -> dict:
        """The state as an amm.units request."""
        r = dict(self.state["targets"])
        if self.state["material"] is not None:
            r["material"] = self.state["material"]
        if self.state["cell_size"] is not None:
            r["cell_size"] = self.state["cell_size"]
        return r

    def normalized(self, strict: bool = True) -> tuple[dict, list[str]]:
        t, missing, _ = units.normalize(self.request())
        if strict and missing:
            raise ToolError("targets cannot be normalized: " + "; ".join(missing))
        return t, missing

    def _phys(self, row: dict) -> dict:
        m, a = self._material(), (self.state["cell_size"][0] * units.LENGTH_UNITS[self.state["cell_size"][1]]
                                   if self.state["cell_size"] else None)
        out = {}
        if m is not None:
            for k in ("E100", "G", "bulk"):
                if row.get(k) is not None:
                    out[f"{k}_MPa"] = row[k] * m["E"] / 1e6
            if a is not None:
                out["gaps_Hz"] = [[g["f_lo"] * units.c_t(m) / a, g["f_hi"] * units.c_t(m) / a]
                                  for g in row.get("gaps", [])[:3]]
        return out

    def _design_spec(self, d: Design) -> dict:
        p = dict(d.params)
        fam = atlas.family_of(d.kind)
        mode = p.pop("mode", None)
        if fam == "tpms" and mode not in atlas.TPMS_MODES:
            raise ToolError(f"TPMS design needs params.mode in {list(atlas.TPMS_MODES)}")
        try:
            p = {k: float(v) for k, v in p.items()}
        except (TypeError, ValueError):
            raise ToolError("design parameters must be numbers (plus mode for TPMS)")
        box = atlas.box(d.kind)
        if set(p) != set(box):
            raise ToolError(f"{d.kind} takes parameters {sorted(box)} (got {sorted(p)})")
        for k, (lo, hi) in box.items():
            if not lo <= p[k] <= hi:
                raise ToolError(f"{d.kind}.{k} = {p[k]} outside the family box [{lo}, {hi}]")
        if not atlas.valid(d.kind, p):
            raise ToolError(f"{d.kind} parameters {p} violate the family's validity rule")
        return atlas.make_spec(d.kind, p, mode)

    def _spend(self, what: str, n: int):
        cap = dict(designs=MAX_SESSION_DESIGNS, certify=MAX_SESSION_CERTIFY)[what]
        if self.used[what] + n > cap:
            raise ToolError(f"session budget exhausted: {self.used[what]} of {cap} {what} used, this call needs {n}")
        self.used[what] += n

    def _cert_key(self, spec: dict, targets: dict) -> str:
        """A certificate is bound to the geometry, the normalized targets AND the physics it was computed with
        (material, Poisson ratio): a change of material never reuses it (audit F02, 2026-11-06)."""
        return hashlib.sha256(canon(dict(spec=spec, targets=targets, material=self.state["material"],
                                         nu=(self._material() or {}).get("nu"))).encode()).hexdigest()[:16]

    # ---- spec ------------------------------------------------------------------------------------------------
    @tool(mutates=True)
    def set_material(self, name: Literal["PA12", "Ti6Al4V", "316L", "AlSi10Mg"] | None = None,
                     E_Pa: float | None = None, nu: float | None = None, rho_kg_m3: float | None = None) -> dict:
        """Set the solid material: a known name, or E_Pa, nu and rho_kg_m3 together. Its Poisson ratio enters every
        solve; E and density convert stiffness and frequency targets."""
        if name is not None:
            self.state["material"] = name
        elif None not in (E_Pa, nu, rho_kg_m3):
            if not (E_Pa > 0 and rho_kg_m3 > 0 and -1 < nu < 0.5):
                raise ToolError("need E_Pa > 0, rho_kg_m3 > 0 and -1 < nu < 0.5")
            self.state["material"] = dict(E=E_Pa, nu=nu, rho=rho_kg_m3)
        else:
            raise ToolError("give a material name, or all of E_Pa, nu and rho_kg_m3")
        m = self._material()
        return dict(material=self.state["material"], E_Pa=m["E"], nu=m["nu"], rho_kg_m3=m["rho"],
                    atlas_available=atlas_rows(m["nu"]) is not None)

    @tool(mutates=True)
    def set_constraints(self, cell_size: float | None = None, cell_size_unit: Literal["mm", "cm", "m", "um", "in"] = "mm",
                        families: list[Family] | None = None) -> dict:
        """Set the unit-cell size a (frequencies scale as 1/a) and the cell families allowed."""
        if cell_size is not None:
            if cell_size <= 0:
                raise ToolError("cell_size must be positive")
            self.state["cell_size"] = [cell_size, cell_size_unit]
        if families is not None:
            if not families:
                raise ToolError("families must not be empty")
            self.state["families"] = list(dict.fromkeys(families))
        return dict(cell_size=self.state["cell_size"], families=self.state["families"])

    @tool(mutates=True)
    def set_target(self, density_max: float | None = None, density_min: float | None = None,
                   E100_min: Stiffness | None = None, E100_max: Stiffness | None = None, G_min: Stiffness | None = None,
                   bulk_min: Stiffness | None = None, nu100_min: float | None = None, nu100_max: float | None = None,
                   gap: Gap | None = None, gap_type: Literal["complete"] | None = None, clear: bool = False) -> dict:
        """Set design targets (replaces only the keys given; clear=True starts from no targets). Stiffness in
        pressure units or "E_s"; density = solid fraction; E100 = Young's modulus along a cube axis; gap = a
        complete elastic-wave band gap covering [f_lo, f_hi] (all directions and polarizations)."""
        t = {} if clear else dict(self.state["targets"])
        for k, v in dict(density_max=density_max, density_min=density_min, nu100_min=nu100_min,
                         nu100_max=nu100_max).items():
            if v is not None:
                t[k] = float(v)
        for k, v in dict(E100_min=E100_min, E100_max=E100_max, G_min=G_min, bulk_min=bulk_min).items():
            if v is not None:
                t[k] = v.value if v.unit == "E_s" else [v.value, v.unit]
        if gap is not None:
            if not 0 < gap.f_lo < gap.f_hi:
                raise ToolError("gap needs 0 < f_lo < f_hi (a band gap cannot contain f = 0)")
            t["gap"] = ({"f_lo": gap.f_lo, "f_hi": gap.f_hi} if gap.unit == "f*" else
                        {"f_lo": [gap.f_lo, gap.unit], "f_hi": [gap.f_hi, gap.unit]})
        if gap_type is not None:
            self.state["gap_type"] = gap_type
        self.state["targets"] = t
        norm, missing = self.normalized(strict=False)
        return dict(targets=t, normalized=norm, cannot_normalize_yet=missing)

    @tool(mutates=True)
    def set_source(self, key: str, source: Literal["stated", "derived", "assumed", "answered"], note: str = "") -> dict:
        """Record where a spec item came from: stated in the brief, derived from it, assumed, or answered by the
        user. Keys: material, cell_size, families, or a target key."""
        known = {"material", "cell_size", "families", "gap_type"} | set(self.state["targets"])
        if key not in known:
            raise ToolError(f"unknown key {key!r} (set keys: {sorted(known)})")
        self.state["sources"][key] = dict(source=source, note=note)
        return dict(sources=self.state["sources"])

    # ---- check -----------------------------------------------------------------------------------------------
    @tool(profiles=("C",))
    def check_bounds(self) -> dict:
        """Rigorous physics bounds on the current targets (Voigt, Hashin-Shtrikman advisory, cubic stability, gap
        rules) and the family-atlas verdict: PROVEN_INFEASIBLE (a bound is violated, named), NOT_FOUND_IN_FAMILIES
        (no atlas cell can meet it even with the most favourable search-tier error), FEASIBLE (an atlas cell meets
        it with the least favourable error) or BORDERLINE. NOT_FOUND is not a proof of impossibility."""
        norm, missing = self.normalized(strict=False)
        if not norm:
            raise ToolError("no targets that can be normalized yet" + (": " + "; ".join(missing) if missing else ""))
        nu = self._nu()
        b = bounds.check(norm, nu_s=nu, missing=missing)
        out = dict(bounds_verdict=b["verdict"], violated=b["violated"], advisory=b["advisory"],
                   normalized_targets=norm, cannot_normalize=missing)
        rows = atlas_rows(nu)
        if rows is None:
            out["atlas"] = dict(verdict="UNAVAILABLE", note=f"no atlas at nu_s = {nu:g} (atlases: 0.3, 0.342, 0.39)")
        else:
            fam = set(self.state["families"])
            o = atlas.oracle([r for r in rows if r["spec"]["family"] in fam], norm)
            out["atlas"] = dict(verdict=o["verdict"], n_cells=o["n_cells"], n_clear=o["n_clear"],
                                n_possible=o["n_possible"], best=o["best"][:3],
                                note="search-tier atlas with calibrated error ranges; FEASIBLE is not a certificate")
        out["verdict"] = ("PROVEN_INFEASIBLE" if b["violated"] else out["atlas"]["verdict"])
        return out

    @tool(replay="answer")
    def ask_clarification(self, question: str, options: list[ClarifyOption]) -> dict:
        """Ask the user one question with 2-5 options. The answer is returned; choosing an option does NOT change
        the spec, so apply it with set_material / set_constraints / set_target afterwards."""
        if not 2 <= len(options) <= 5:
            raise ToolError("give 2-5 options")
        opts = [o.model_dump() for o in options]
        if self.replay_answer is not None:
            ans = self.replay_answer
        elif self.answerer is None:
            raise ToolError("no user is available to answer in this session")
        else:
            ans = self.answerer(question, opts)
        return dict(question=question, answer=ans)

    # ---- design ----------------------------------------------------------------------------------------------
    @tool()
    def list_families(self) -> dict:
        """The cell families, their kinds, parameter boxes and validity rules."""
        from . import geometry
        out = {}
        for fam, kinds in geometry.FAMILIES.items():
            out[fam] = {k: dict(params={n: list(b) for n, b in atlas.box(k).items()},
                                modes=list(atlas.TPMS_MODES) if fam == "tpms" else None) for k in kinds}
        return dict(families=out, rules=dict(
            struts="R = 0 (no node sphere) or R >= r + 0.03",
            cube_bars="w <= c - 0.04", sphere_ligaments="w <= 2 c - 0.02",
            tpms="network TPMS do not percolate below density ~0.10 (Schwarz P ~0.15)"),
            units="lengths in units of the cell size a; density = solid fraction")

    @tool()
    def atlas_suggest(self, top: int = 5) -> dict:
        """The atlas cells (2,722 precomputed cells per material Poisson ratio, search tier) that come closest to the
        current targets, best first, with nominal and pessimistic slack (> 0 means met). Search-tier values, NOT
        certificates; costs no evaluations. Same in every profile (audit F07)."""
        if not 1 <= top <= 10:
            raise ToolError("top must be 1-10")
        norm, _ = self.normalized()
        if not norm:
            raise ToolError("no targets set")
        rows = atlas_rows(self._nu())
        if rows is None:
            raise ToolError(f"no atlas at nu_s = {self._nu():g} (atlases: 0.3, 0.342, 0.39)")
        fam = set(self.state["families"])
        o = atlas.oracle([r for r in rows if r["spec"]["family"] in fam], norm, top=top)
        out = []
        for b in o["best"]:
            sp = b["spec"]
            out.append(dict(design=dict(kind=sp["kind"], params=sp["params"]),
                            slack_nominal=b["slack_nominal"], slack_pess=b["slack_pess"]))
        return dict(best=out, normalized_targets=norm, tier="search (not certified)")

    @tool()
    def evaluate(self, designs: list[Design]) -> dict:
        """Search-tier properties of up to 16 designs (fast, about 1-2 s each; NOT certified, biased stiff and
        high in frequency by several %): density, E100, G, bulk, nu100 (normalized by E_s), complete band gaps
        (normalized f* = f a / c_t, and Hz when material and cell size are set)."""
        if not 1 <= len(designs) <= MAX_EVAL:
            raise ToolError(f"give 1-{MAX_EVAL} designs")
        from . import evaluate as ev
        specs = [self._design_spec(d) for d in designs]
        self._spend("designs", len(specs))
        rows = ev.evaluate_batch(specs, nu=self._nu(), keep_bands=True, **atlas.SEARCH_TIER)  # gaps need bands
        out = []
        for r in rows:
            v = {k: r.get(k) for k in ("density", "E100", "G", "bulk", "nu100", "valid")}
            v["gaps"] = [dict(f_lo=g["f_lo"], f_hi=g["f_hi"], rel=g["rel"]) for g in atlas.row_gaps(r, 0.01)[:3]]
            v.update(self._phys(dict(r, gaps=v["gaps"])))
            out.append(dict(design=dict(kind=r["spec"]["kind"], params=r["spec"]["params"]), **v))
        return dict(results=out, tier="search (not certified)")

    @tool()
    def search(self, budget: int = 32, families: list[Family] | None = None,
               objective: Literal["expected", "pess", "nominal"] = "expected", margin: float = 0.0) -> dict:
        """Bayesian optimization (BoTorch) over the family parameters for the current targets, seeded by the
        family atlas. Slack = relative distance to the nearest target (> 0 means met). objective "expected" uses
        search-tier values corrected by the calibrated median error; margin asks for slack > margin. Returns the 5
        best designs with nominal / expected / pessimistic slack. Search-tier values, NOT certificates. Takes 1-15
        minutes (wide gap targets take longest); tools run one call at a time, so wait for the result."""
        if not 8 <= budget <= 96:
            raise ToolError("budget must be 8-96 evaluations")
        norm, _ = self.normalized()
        if not norm:
            raise ToolError("no targets set")
        from . import search as srch
        nu = self._nu()
        self._spend("designs", budget)
        fams = families or self.state["families"]
        rows = atlas_rows(nu)
        r = srch.search(norm, nu=nu, families=fams, budget=budget, q=8, objective=objective, seed=0,
                        atlas_rows=[x for x in rows if x["spec"]["family"] in fams] if rows else None)
        best = []
        for b in r["best"]:
            d = dict(design=dict(kind=b["spec"]["kind"], params=b["spec"]["params"]),
                     slack_nominal=b["slack_nominal"], slack_expected=b["slack_expected"],
                     slack_pess=b["slack_pess"], values=b["values"],
                     gaps=[dict(f_lo=g["f_lo"], f_hi=g["f_hi"], rel=g["rel"]) for g in b["gaps"]],
                     calibrated_domain=b["calibrated"], from_atlas=b["from_atlas"])
            d.update(self._phys(dict(b["values"], gaps=d["gaps"])))
            best.append(d)
        key = f"slack_{objective}"
        return dict(best=best, found=bool(best and best[0][key] > margin), objective=objective, margin=margin,
                    n_evaluations=r["n_evaluations"], arms=r["arms"], normalized_targets=norm,
                    atlas_seeded=rows is not None, tier="search (not certified)")

    # ---- release ---------------------------------------------------------------------------------------------
    @tool(profiles=("C",))
    def certify(self, design: Design) -> dict:
        """Certificate of one design against the current targets (2-20 minutes; wait for the result): static properties by a three-
        resolution ladder with grid phases and a guarded error bound; complete band gap by inertia counts over the
        Brillouin zone at two resolutions with an edge-convergence guard; as-built offset +-0.01 a as a robustness
        flag. Verdict: certified / refuted / undetermined (inside the guard band: neither proven nor disproven).
        Only a certified design can be released."""
        from . import certify as cf
        norm, _ = self.normalized()
        if not norm:
            raise ToolError("no targets set")
        spec = self._design_spec(design)
        self._spend("certify", 1)
        c = cf.certify(spec, norm, nu=self._nu())
        st, bl = c["blocks"]["static"], c["blocks"].get("bloch")
        conv = (st.get("convergence") or {}).get("quantities") or {}
        summ = dict(design=dict(kind=spec["kind"], params=spec["params"]), verdict=c["verdict"], robust=c["robust"],
                    static=dict(verdict=st["verdict"], rung=st.get("used"),
                                bounds={q: dict(lower=v["lower"], upper=v["upper"]) for q, v in conv.items()},
                                checks_failed=st.get("checks_failed")),
                    targets=norm, spec_hash=c["spec_hash"])
        if bl is not None:
            cv = bl.get("convergence") or {}
            summ["gap"] = dict(verdict=bl["verdict"], safe_interval=cv.get("safe_interval"),
                               claim=[norm["gap"]["f_lo"], norm["gap"]["f_hi"]])
        if "as_built" in c["blocks"]:
            summ["as_built"] = {k: v.get("passed") for k, v in c["blocks"]["as_built"]["cases"].items()}
        summ.update(self._phys({q: v["lower"] for q, v in conv.items()}))
        self.certs[self._cert_key(spec, norm)] = dict(verdict=c["verdict"], robust=c["robust"],
                                                      material=self.state["material"], nu=self._nu(),
                                                      checker=c.get("checker"))
        if self.root is not None:
            d = self.root / "certificates"
            d.mkdir(exist_ok=True)
            (d / f"{c['spec_hash']}_{self._cert_key(spec, norm)}.json").write_text(canon(c), encoding="utf-8")
        return summ

    @tool(mutates=True)
    def submit(self, decision: Literal["release", "refuse", "need_info"], design: Design | None = None,
               verdict: Literal["PROVEN_INFEASIBLE", "NOT_FOUND_IN_FAMILIES", "UNDETERMINED", "OTHER"] | None = None,
               note: str = "") -> dict:
        """Final answer of the session: release one design, refuse the request (say why with `verdict`), or
        stop because information is missing. Profile C releases only a design certified in this session for the
        current targets."""
        if self.submission is not None:
            raise ToolError("already submitted")
        sub = dict(decision=decision, note=note)
        if decision == "release":
            if design is None:
                raise ToolError("release needs a design")
            norm, _ = self.normalized()
            spec = self._design_spec(design)
            cert = self.certs.get(self._cert_key(spec, norm))
            if self.profile == "C" and (cert is None or cert["verdict"] != "certified"):
                raise ToolError("release needs a certificate with verdict 'certified' for this design and the current "
                                "targets: call certify first" + (f" (its verdict was {cert['verdict']})" if cert else ""))
            sub.update(design=dict(kind=spec["kind"], params=spec["params"]), targets=norm,
                       certificate=cert)
        elif decision == "refuse":
            if verdict is None:
                raise ToolError("refuse needs a verdict")
            sub["verdict"] = verdict
        # the spec as it stands at submission (audit F04): scoring reads this, not later calls
        sub["spec"] = dict(material=self.state["material"], nu=self._nu() if self.state["material"] else None,
                           cell_size=self.state["cell_size"], targets=dict(self.state["targets"]),
                           gap_type=self.state.get("gap_type"))
        self.submission = sub
        return dict(submitted=sub)

    # ---- session ---------------------------------------------------------------------------------------------
    @tool(mutates=True)
    def undo(self) -> dict:
        """Undo the last change to the spec."""
        if not self.undo_stack:
            raise ToolError("nothing to undo")
        self.state = self.undo_stack.pop()
        return dict(state=self.state)

    @tool()
    def get_session(self) -> dict:
        """The current spec (material, cell size, targets, families, sources), normalized targets, the
        certificates computed so far and the submission."""
        norm, missing = self.normalized(strict=False)
        return dict(state=self.state, normalized_targets=norm, cannot_normalize=missing,
                    certificates=self.certs, submission=self.submission, profile=self.profile, tools=self.tools(),
                    budget_used=self.used, budget=dict(designs=MAX_SESSION_DESIGNS, certify=MAX_SESSION_CERTIFY))


# ----------------------------------------------------------------------------------------------------------------
# replay
# ----------------------------------------------------------------------------------------------------------------
def read_log(path) -> list[dict]:
    return [json.loads(l) for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]


def replay(log, root=None, skip_tools=()) -> dict:
    """Re-run a session log without any LLM. Every call is re-executed in a fresh session of the same profile;
    ok flag, state hash and the result (timing fields removed) must match. Clarification answers are taken from
    the log. Returns {exact, n_calls, n_compared, mismatches}."""
    recs = read_log(log) if not isinstance(log, list) else log
    head = next(r for r in recs if r.get("type") == "session")
    s = Session(root, profile=head["profile"])
    mism, n = [], 0
    calls = [r for r in recs if r.get("type") == "call"]
    for e in calls:
        if e["tool"] in skip_tools:
            continue
        if e["tool"] == "ask_clarification" and e["ok"]:
            s.replay_answer = e.get("answer")
        out = s.call(e["tool"], e["args"], actor=e["actor"])
        s.replay_answer = None
        n += 1
        if out["ok"] != e["ok"]:
            mism.append(dict(seq=e["seq"], tool=e["tool"], field="ok", log=e["ok"], replay=out["ok"],
                             error=out.get("error")))
            continue
        if out["state_hash"] != e["state_hash"]:
            mism.append(dict(seq=e["seq"], tool=e["tool"], field="state_hash", log=e["state_hash"],
                             replay=out["state_hash"]))
        if e["ok"] and result_hash(out["result"]) != e.get("result_hash", result_hash(e["result"])):
            mism.append(dict(seq=e["seq"], tool=e["tool"], field="result", log=e.get("result_hash"),
                             replay=result_hash(out["result"]), diff=_first_diff(strip_volatile(e["result"]),
                                                                                  strip_volatile(out["result"]))))
        if not e["ok"] and out.get("error") != e.get("error"):
            mism.append(dict(seq=e["seq"], tool=e["tool"], field="error", log=e.get("error"), replay=out.get("error")))
    return dict(exact=not mism, n_calls=len(calls), n_compared=n, mismatches=mism,
                same_code=head.get("code") == code_hash())


def _first_diff(a, b, path=""):
    if type(a) is not type(b):
        return dict(path=path, log=a, replay=b)
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b:
                return dict(path=f"{path}.{k}", log=a.get(k), replay=b.get(k))
            d = _first_diff(a[k], b[k], f"{path}.{k}")
            if d:
                return d
        return None
    if isinstance(a, list):
        if len(a) != len(b):
            return dict(path=path, log=f"len {len(a)}", replay=f"len {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)):
            d = _first_diff(x, y, f"{path}[{i}]")
            if d:
                return d
        return None
    return None if a == b else dict(path=path, log=a, replay=b)
