"""AgenticMetamaterials core package (independent project; see 00_INDEPENDENT_PROJECT__NOT_AgenticTO.md).

Units inside the solvers are normalized: solid Young's modulus E_s = 1, Poisson ratio nu_s, density rho_s = 1,
cell edge a = 1. Frequencies are reported as f* = f a / c_t with c_t the solid's shear-wave speed.
"""
__version__ = "0.1.0"

# Load MKL (pypardiso) before torch. Both ship Intel's libiomp5md.dll; if torch's copy initializes first,
# MKL aborts with "OMP: Error #15". With MKL first, one runtime is initialized and both libraries share it.
# Importing pypardiso is not enough: MKL initializes its OpenMP runtime on the first solve, so do a 1x1 solve.
# PARDISO is memory-bound here: 16 threads (the 8 P-cores with HT on the i9-13900KF) beat 32 (1.07 vs 1.43 s per
# n=30 factorization, 2026-11-03). Override with MKL_NUM_THREADS.
import os as _os

_os.environ.setdefault("MKL_NUM_THREADS", "16")
# Bit-reproducible MKL (conditional numerical reproducibility): without it, threaded PARDISO results differ in the
# last bits between processes, which breaks exact replay of agent sessions (amm.tools.replay). AUTO,STRICT keeps the
# fastest code path for this CPU; cost about 4 % on a static solve (results/probe/NOTES.md). The variable must be
# set before MKL initializes, so it is also set by the launchers (amm.llm); MKL_CBWR_STATUS records what took.
_os.environ.setdefault("MKL_CBWR", "AUTO,STRICT")
MKL_CBWR_STATUS = None
try:  # pragma: no cover - import-order guard
    import numpy as _np
    import pypardiso as _pypardiso
    import scipy.sparse as _sp

    _pypardiso.spsolve(_sp.csr_matrix(_np.ones((1, 1))), _np.ones(1))
    try:
        _lib = _pypardiso.ps.libmkl  # the mkl_rt that PARDISO runs on
        MKL_CBWR_STATUS = int(_lib.MKL_CBWR_Get(-1))  # MKL_CBWR_ALL; AUTO|STRICT = 0x10002 = 65538, off = 1
    except Exception:
        MKL_CBWR_STATUS = None
except ImportError:
    pass
