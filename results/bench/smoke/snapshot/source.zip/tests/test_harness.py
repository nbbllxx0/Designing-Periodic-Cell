"""E4 harness (audit 2026-11-06, F03): arm D logging, arm O on the oracle spec, run records, partition. No LLM."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "bench"))
import scoring  # noqa: E402
from amm import bench, tools  # noqa: E402


def brief(bid):
    return json.loads((ROOT / "bench" / "v1" / "briefs" / f"{bid}.json").read_text(encoding="utf-8"))


def test_intended_tool_args_reproduce_the_intended_request(tmp_path):
    for bid in ("G01", "M01", "S01", "X01", "A05"):
        b = brief(bid)
        a = bench.intended_tool_args(b["intended"])
        s = tools.Session(None, profile="C")
        assert s.call("set_material", {"name": a["material"]})["ok"]
        if a["constraints"]:
            assert s.call("set_constraints", a["constraints"])["ok"]
        assert s.call("set_target", a["targets"])["ok"]
        norm, _ = s.normalized()
        assert scoring._close(norm, scoring.intended_normalized(b), 1e-9), bid


def test_direct_answer_is_logged_through_the_tool_contract(tmp_path):
    b = brief("S01")
    a = bench.intended_tool_args(b["intended"])
    ans = dict(decision="release", material=a["material"], cell_size=None, targets=a["targets"],
               design=dict(kind="gyroid", params=dict(density=0.3, mode="sheet")), note="from memory")
    txt = "Here is my answer:\n" + json.dumps(ans)
    s = tools.Session(tmp_path / "session", profile="B")
    bench._log_direct_answer(s, bench._last_json(txt))
    r = scoring.score_session(b, tmp_path, certify_releases=False)
    assert r["decision"] == "release" and r["spec_ok"] and r["outcome"] == "pending"


def test_run_brief_always_writes_a_record(tmp_path):
    p = tmp_path / "request.json"
    p.write_text(json.dumps(bench.load_brief(ROOT / "bench" / "v1" / "briefs" / "S01.json")), encoding="utf-8")
    rec = bench.run_brief(p, tmp_path / "job", profile="Z")
    assert rec["status"] == "error" and "unknown arm" in rec["error"]
    assert (tmp_path / "job" / "run.json").exists()


def test_baseline_refuses_a_proven_infeasible_brief_without_a_solve(tmp_path):
    b = brief("X01")
    p = tmp_path / "request.json"
    p.write_text(json.dumps(dict(text=b["text"], intended=b["intended"], oracle=b["oracle"])), encoding="utf-8")
    rec = bench.run_brief(p, tmp_path / "job", profile="O")
    assert rec["status"] == "done", rec
    r = scoring.score_session(b, tmp_path / "job", certify_releases=False)
    assert r["outcome"] == "correct_refusal" and r["verdict_match"] == "exact" and r["correct"]


def test_partition_matches_the_audit_counts():
    import e4
    b = e4.load_briefs()
    part = e4.partition(b)
    conf = [i for i in b if part[i] == "confirmatory"]
    assert len(conf) == 78 and len({scoring.spec_key(b[i]) for i in conf}) == 61
    assert all(part[i] == "development" for i in ("S01", "R01", "A04"))


def test_deidentified_request_has_no_label():
    import e4
    d = e4.deidentified(brief("X01"))
    assert set(d) == {"text", "intended", "oracle"} and "X01" not in json.dumps(d)
