"""Speed + sanity benchmark of the search tier and one full certificate. Writes results/speed/<tag>.json."""
import argparse, json, time
import amm  # noqa: F401  (MKL before torch)
from amm import certify as C, evaluate as EV

SPECS = ([dict(family="resonator", kind="cube_bars", params=dict(c=c, w=w)) for c in (0.5, 0.6, 0.7) for w in (0.1, 0.2, 0.3)]
         + [dict(family="tpms", kind=k, params=dict(density=0.25, mode="network")) for k in ("gyroid", "schwarz_p", "diamond", "iwp")]
         + [dict(family="struts", kind=k, params=dict(r=0.08, R=0.18)) for k in ("sc", "bcc", "octet")])

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--tag", default="run"); ap.add_argument("--no-cert", action="store_true")
    a = ap.parse_args()
    EV.evaluate(SPECS[0])  # CUDA warm-up
    t = time.perf_counter(); res = EV.evaluate_batch(SPECS); dt = time.perf_counter() - t
    print(f"search tier: {len(SPECS)} cells in {dt:.1f}s ({dt/len(SPECS):.2f}s/cell)")
    for r in res:
        s = r["spec"]
        print(f"{s['family']:9s} {s['kind']:16s} {json.dumps(s['params']):38s} rho={r.get('density',0):.3f} "
              f"E100={r.get('E100',0):.4f} nu={r.get('nu100',0):+.3f} gap={r.get('best_rel_gap',0):.3f} "
              f"valid={r.get('valid')}/{r.get('bloch_valid')}")
    out = dict(search=dict(n=len(SPECS), seconds=dt, results=[{k: v for k, v in r.items() if k != 'gaps'} | {'gaps': r.get('gaps')} for r in res]))
    if not a.no_cert:
        spec = dict(family="resonator", kind="cube_bars", params=dict(c=0.6, w=0.2))
        g = [r for r in res if r["spec"] == spec][0]["gaps"][0]
        lo, hi = g["f_lo"], g["f_hi"]
        claim = dict(f_lo=round(lo + 0.25 * (hi - lo), 3), f_hi=round(hi - 0.25 * (hi - lo), 3))
        print("certifying", spec, "gap claim", claim, "(search-tier gap", round(lo, 3), round(hi, 3), ")")
        cert = C.certify(spec, dict(density_max=0.30, E100_min=0.02, gap=claim))
        st = cert["blocks"]["static"]; bl = cert["blocks"]["bloch"]; ab = cert["blocks"]["as_built"]
        print("CERT passed", cert["passed"], "robust", cert["robust"], "total", cert["seconds"], "s")
        print(" timing", cert["timing"])
        print(" static", st["passed"], "pair", st["used"], {n: (round(v["E100"], 4), round(v["G"], 5), round(v["density"], 4), v["numerics_ok"], v["seconds"]) for n, v in st["resolutions"].items()},
              [{k: round(v, 4) for k, v in t["agreement"].items()} for t in st["ladder"]])
        print(" bloch", bl["passed"], "below_band", bl["claim"]["below_band"], "rho spread", round(bl["density_spread"], 4),
              {n: (v["passed"], v["n_failures"], v["numerically_sane"], v["seconds"]) for n, v in bl["resolutions"].items()})
        print(" as_built", {k: (v["passed"], round(v.get("E100", 0), 4), v.get("gap_ok")) for k, v in ab["cases"].items()})
        out["certificate"] = cert
    json.dump(out, open(f"results/speed/{a.tag}.json", "w"), indent=1, default=float)
