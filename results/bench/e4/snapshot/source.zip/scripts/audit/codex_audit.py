"""Independent progress audit by Codex (gpt-6.1-sol, effort high) on the ChatGPT subscription, read-only sandbox.

Same subscription policy as the agent runs (amm.llm): API-key and endpoint variables stripped, ChatGPT login
checked and forced. The auditor reads the project; it cannot write. Its report is results/audit/<tag>/report.md.

    codex_audit.py <tag> <prompt_file>
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from amm import llm  # noqa: E402


def main(tag: str, prompt_file: str):
    out = ROOT / "results" / "audit" / tag
    out.mkdir(parents=True, exist_ok=True)
    auth = llm.assert_subscription_only("codex")
    prompt = Path(prompt_file).read_text(encoding="utf-8")
    (out / "prompt.md").write_text(prompt, encoding="utf-8")
    exe = llm.codex_bin()
    cmd = [exe, "exec", "--json", "--ephemeral", "--ignore-user-config", "--skip-git-repo-check",
           "-s", "read-only", "-C", str(ROOT), "-m", llm.DEFAULT_CODEX_MODEL,
           "-c", f'model_reasoning_effort="{llm.DEFAULT_CODEX_EFFORT}"', "-c", 'forced_login_method="chatgpt"',
           "-c", 'windows.sandbox="unelevated"', "-c", 'approval_policy="never"',  # read access on Windows
           "-o", str(out / "report.md"), "-"]
    t = time.perf_counter()
    p = subprocess.run(cmd, input=prompt, capture_output=True, text=True, encoding="utf-8", timeout=10800,
                       env=llm._clean_env())
    (out / "events.jsonl").write_text(p.stdout, encoding="utf-8")
    (out / "stderr.txt").write_text(p.stderr, encoding="utf-8")
    (out / "auth.txt").write_text(f"{auth}\nforced_login_method=chatgpt\nwall_s={time.perf_counter() - t:.0f}\n"
                                  f"returncode={p.returncode}\n", encoding="utf-8")
    print("audit done", p.returncode, f"{time.perf_counter() - t:.0f} s", out / "report.md")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
